import React from 'react';
declare const HeroCarousel: ({ children }: React.PropsWithChildren) => React.JSX.Element;
export default HeroCarousel;
