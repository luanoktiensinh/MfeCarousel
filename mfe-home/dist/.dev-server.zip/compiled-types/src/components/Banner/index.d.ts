/// <reference types="react" />
declare const Banner: () => import("react").JSX.Element;
export default Banner;
