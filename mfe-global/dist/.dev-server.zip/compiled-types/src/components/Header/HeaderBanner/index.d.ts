/// <reference types="react" />
declare const HeaderBanner: () => import("react").JSX.Element;
export default HeaderBanner;
